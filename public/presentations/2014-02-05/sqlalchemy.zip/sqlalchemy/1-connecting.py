# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine

from helpers import SQLITE_URI

# Create a new engine specification
# engine = create_engine('sqlite:///:memory:', echo=True)
engine = create_engine(SQLITE_URI, echo=True)

# SQL w/ literal values
numbers = engine.execute("SELECT 1, 2, 3").first()
print('')
print(numbers)
print('')

# SQL w/ bind values  (SQLite specific syntax)
numbers2 = engine.execute("SELECT :1, :2, :3", (1, 2, 3)).first()
print('')
print(numbers2)
print('')