# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, joinedload

from helpers import session_context, MAIN_URI
from ticketmodels import Base, create_data, Patron, Play, Ticket, Performance

# Reset the database and create some data
creator = create_engine(MAIN_URI)
Base.metadata.drop_all(bind=creator)
Base.metadata.create_all(bind=creator)
with session_context(sessionmaker(bind=creator)) as session:
    create_data(session)

# Start playing around
engine = create_engine(MAIN_URI, echo=True)
SessionMaker = sessionmaker(bind=engine)


# ----------------------------------------------------------------------------
# Use Case - Buy a ticket (relationship chasing)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:

    # Find Patron
    patron = session.query(Patron).filter(Patron.first == "David").one()

    # Find Phantom
    phantom = session.query(Play).filter(Play.id == 3).one()

    # Get some good tickets
    tickets = phantom.performances[0].tickets[:2]

    # Buy
    for ticket in tickets:
        ticket.patron = patron


# ----------------------------------------------------------------------------
# Use Case - Buy a ticket (Use the database a little)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:

    # Find Patron
    patron = session.query(Patron).filter(Patron.first == "David").one()

     # Find Wine Tasting
    wine_tasting = session.query(Play).filter(Play.id == 1).one()

    # Get some good tickets
    tickets = (
        session.query(Ticket).
        join(Ticket.performance).
        filter(Performance.play == wine_tasting).
        filter(Ticket.patron == None).
        limit(2).
        all())

    # Buy
    for ticket in tickets:
        ticket.patron = patron


# ----------------------------------------------------------------------------
# Use Case - Buy a ticket (Use the database a lot) -- Maybe premature optimization
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:

    # Find some tickets for Book of Mormon
    tickets_query = (
        session.query(Ticket.id).
        join(Ticket.performance).
        join(Performance.play).
        filter(Play.id == 4).
        filter(Ticket.patron == None).
        limit(2)
    )

    # Update database with Patron #1 as buyer ("David McKeone")
    (session.query(Ticket).
     filter(Ticket.id.in_(tickets_query)).
     update({'patron_id': 1}, synchronize_session=False))


# ----------------------------------------------------------------------------
# Use Case - Report on all patrons for a ticket (Lazy load)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:

    # Find Patron
    patron = session.query(Patron).filter(Patron.first == "David").one()

    # Get tickets
    lazy_tickets = patron.tickets
    print('')
    print("Tickets (lazy load): ", lazy_tickets)
    print('')


# ----------------------------------------------------------------------------
# Use Case - Report on all patrons for a ticket (Joined load)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:
    # Find Patron w/tickets
    patron = session.query(Patron).filter(Patron.first == "David").options(joinedload(Patron.tickets)).one()

    # Get tickets
    joined_tickets = patron.tickets
    print('')
    print("Tickets (joined load): ", joined_tickets)
    print('')


# ----------------------------------------------------------------------------
# Use Case - Report on ticket buyers in a play (lazy load)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:
    # Find Patron w/tickets
    play = (
        session.query(Play).
        filter(Play.name.ilike("%phantom%")).
        one()
    )

    # Get performances
    print('')
    print("Performances (lazy load): ", play.performances)
    print('')

    # Get performances for with purchased tickets
    performances = {perf for perf in play.performances for tick in perf.tickets if tick.patron is not None}
    print('')
    print("Performances with purchased tickets (lazy load): ", performances)
    print('')

    # Get bought tickets
    tickets = [tick for perf in play.performances for tick in perf.tickets if tick.patron is not None]
    print('')
    print("Tickets (lazy load): ", tickets)
    print('')

    # Get patrons who bought the tickets
    patrons = {ticket.patron for ticket in tickets}
    print('')
    print("Patrons (lazy load): ", patrons)
    print('')


# ----------------------------------------------------------------------------
# Use Case - Report on ticket buyers in a play (joined load)
# ----------------------------------------------------------------------------
with session_context(SessionMaker) as session:
    # Find Patron w/tickets
    play = (
        session.query(Play).
        filter(Play.name.ilike("%phantom%")).
        options(joinedload('performances')).
        options(joinedload('performances.tickets')).
        options(joinedload('performances.tickets.patron')).
        one()
    )

    # Get performances
    print('')
    print("Performances (joined load): ", play.performances)
    print('')

    # Get performances for with purchased tickets
    performances = {perf for perf in play.performances for tick in perf.tickets if tick.patron is not None}
    print('')
    print("Performances with purchased tickets (joined load): ", performances)
    print('')

    # Get bought tickets
    tickets = [tick for perf in play.performances for tick in perf.tickets if tick.patron is not None]
    print('')
    print("Tickets (joined load): ", tickets)
    print('')

    # Get patrons who bought the tickets
    patrons = {ticket.patron for ticket in tickets}
    print('')
    print("Patrons (joined load): ", patrons)
    print('')