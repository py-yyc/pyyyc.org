# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, joinedload

from helpers import session_context, MAIN_URI
from ticketmodels import Base, create_data, Patron, Play, Ticket, Performance, Venue, Seat

# Reset the database and create some data
creator = create_engine(MAIN_URI)
Base.metadata.drop_all(bind=creator)
Base.metadata.create_all(bind=creator)
with session_context(sessionmaker(bind=creator)) as session:
    create_data(session)

# Start playing around
engine = create_engine(MAIN_URI, echo=True)
SessionMaker = sessionmaker(bind=engine)


# Purchase in database
with session_context(SessionMaker) as session:

    patron = session.query(Patron).first()
    ticket = session.query(Ticket).filter(Ticket.patron == None).first()

    assert ticket.patron is None
    patron.buy_ticket(ticket)
    assert ticket.patron == patron


# Purchase outside of database
patron = Patron(first="Bob", last="Jones")
venue = Venue(name="Really Small Theatre")
seat = Seat(venue=venue, section='AA', row='A', seat=1)
play = Play(venue=venue, name="One is the loneliest number")
performance = Performance(play=play, code="1-FRI", date=datetime(2014, 5, 16, 18, 00))
ticket = Ticket(performance=performance, seat=seat)

assert ticket.patron is None
patron.buy_ticket(ticket)
assert ticket.patron == patron


# Composability
class TicketLoaderABC(object):

    def get(self):
        raise NotImplementedError


class DBLoader(TicketLoaderABC):
    """
    Load objects from database
    """

    def __init__(self, session):
        self.session = session

    def get(self):
        patron = self.session.query(Patron).first()
        ticket = (
            session.query(Ticket).
            filter(Ticket.patron == None).
            options(joinedload('performance')).
            options(joinedload('performance.play')).
            options(joinedload('seat')).
            options(joinedload('seat.venue')).
            first()
        )
        return patron, ticket


class MemoryLoader(TicketLoaderABC):
    """
    Load objects from memory
    """

    def get(self):
        patron = Patron(first="Bob", last="Jones")
        venue = Venue(name="Really Small Theatre")
        seat = Seat(venue=venue, section='AA', row='A', seat=1)
        play = Play(venue=venue, name="One is the loneliest number")
        performance = Performance(play=play, code="1-FRI", date=datetime(2014, 5, 16, 18, 00))
        ticket = Ticket(performance=performance, seat=seat)

        return patron, ticket


def buy_ticket(loader):
    """
    Buy a ticket with the given loader
    """
    patron, ticket = loader.get()

    assert ticket.patron is None
    patron.buy_ticket(ticket)
    assert ticket.patron == patron


# Traditional database data source
with session_context(SessionMaker) as session:
    buy_ticket(DBLoader(session))

# Same behaviour different data source
buy_ticket(MemoryLoader())