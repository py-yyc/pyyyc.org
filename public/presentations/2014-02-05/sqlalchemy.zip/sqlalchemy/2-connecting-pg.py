# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine

from helpers import POSTGRESQL_URI

# Create a new engine specification
# engine = create_engine(PGSQL_CONNECT_URI, echo=True)
engine = create_engine(POSTGRESQL_URI, echo=True)

# SQL w/ literal values
numbers = engine.execute("SELECT 1, 2, 3").first()
print('')
print(numbers)
print('')

# SQL w/ bind values  (Pyscopg2 specific syntax)
numbers2 = engine.execute("SELECT %s, %s, %s", (1, 2, 3)).first()
print('')
print(numbers2)
print('')