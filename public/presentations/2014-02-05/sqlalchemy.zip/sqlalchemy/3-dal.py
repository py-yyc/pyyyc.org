# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String

from helpers import MAIN_URI

# Create a new engine specification
engine = create_engine(MAIN_URI, echo=True)

metadata = MetaData()
users = Table(
    'user', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String),
    Column('fullname', String)
)

metadata.drop_all(bind=engine)
metadata.create_all(bind=engine)

ins = users.insert()
print(str(ins))
print('')

ins= ins.values(name='dave', fullname="David McKeone")
print(str(ins))
print('')

print(ins.compile().params)

conn = engine.connect()

result = conn.execute(ins)

print("Primary Key: ", result.inserted_primary_key)

sel = users.select(users.c.id == 1)
print(str(ins))
print('')

result_proxy = conn.execute(sel)
print(str(result_proxy))
print('')
print('Rows: ', result_proxy.rowcount)
print('')

result_rows = result_proxy.fetchall()
print(result_rows)
print('')

result_proxy.close()

conn.close()