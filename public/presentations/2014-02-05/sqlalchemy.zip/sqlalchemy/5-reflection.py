# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine, MetaData, Table

from helpers import MAIN_URI

engine = create_engine(MAIN_URI, echo=True)

metadata = MetaData()

# Build Metadata from an existing schema!
messages = Table('user', metadata, autoload=True, autoload_with=engine)
print([c.name for c in messages.columns])