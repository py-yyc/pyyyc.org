# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String
from sqlalchemy.orm import mapper, sessionmaker

from helpers import MAIN_URI

engine = create_engine(MAIN_URI, echo=True)

# Schema
metadata = MetaData()

users = Table('user', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(50)),
    Column('fullname', String(120))
)

metadata.drop_all(bind=engine)
metadata.create_all(bind=engine)

# Plain old object
class User(object):

    def __init__(self, name=None, fullname=None):
        self.name = name
        self.fullname = fullname

    def __repr__(self):
        return '<User {name}>'.format(name=self.name)

# Alchemize!
print(dir(User))
mapper(User, users)
print(dir(User))  # Attribute and _sa_class_manager magic!

# Database session
SessionMaker = sessionmaker(bind=engine)
session = SessionMaker()

# --------------------------
# CREATE
# --------------------------
user = User(name='dave', fullname='David McKeone')
session.add(user)
session.commit()
print('')
# noinspection PyUnresolvedReferences
print(user.id)
print('')

# --------------------------
# READ
# --------------------------
# noinspection PyUnresolvedReferences
user_query = session.query(User).filter(User.id == 1)
print('')
print(str(user_query.statement))
print('')

result = user_query.all()
print('')
print(result)
print('')

# --------------------------
# UPDATE
# --------------------------
user = result[0]
user.name ='david'
session.commit()

# --------------------------
# DELETE
# --------------------------
session.delete(user)
session.commit()