# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from helpers import MAIN_URI

engine = create_engine(MAIN_URI, echo=True)

Base = declarative_base()

# Plain old object
class User(Base):

    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    fullname = Column(String)

    def __init__(self, name=None, fullname=None):
        self.name = name
        self.fullname = fullname

    def __repr__(self):
        return '<User {name}>'.format(name=self.name)


# Table still available via __table__
print('')
print(repr(User.__table__))
print('')

# Metadata available via Base class
Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

# Database session
SessionMaker = sessionmaker(bind=engine)
session = SessionMaker()

# --------------------------
# CREATE
# --------------------------
user = User(name='dave', fullname='David McKeone')
session.add(user)
session.commit()
print('')
print(user.id)
print('')

# --------------------------
# READ
# --------------------------
user_query = session.query(User).filter(User.id == 1)
print('')
print(str(user_query.statement))
print('')

result = user_query.all()
print('')
print(result)
print('')

# --------------------------
# UPDATE
# --------------------------
user = result[0]
user.name ='david'
session.commit()

# --------------------------
# DELETE
# --------------------------
session.delete(user)
session.commit()