# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from concurrent.futures import ThreadPoolExecutor, as_completed
from time import sleep

from sqlalchemy import create_engine, Column, Integer, String, select
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session

from helpers import MAIN_URI

MAX_WORKERS = 1
JOBS = 1

engine = create_engine(MAIN_URI, echo=True)

Base = declarative_base()

# Plain old object
class User(Base):

    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    fullname = Column(String)

    def __init__(self, name=None, fullname=None):
        self.name = name
        self.fullname = fullname

    def __repr__(self):
        return '<User {name}>'.format(name=self.name)

Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

# Database thread-scoped session
SessionMaker = sessionmaker(bind=engine)
session = scoped_session(SessionMaker)

# Thread entry point
def run():
    """
    Work that each thread will do
    """
    # Execute direct (works with plain sql)
    session.execute("SELECT 1")

    # Execute direct (works with SQLAlchemy Expression Language)
    session.execute(select([1]))

    # Create
    user = User(name='dave', fullname='David McKeone')
    session.add(user)
    session.flush()  # Visible in the transaction

    # Read with SQLAlchemy Core
    users = session.execute(select([User])).fetchall()
    print('')
    print('Users (Core)', users)
    print('')

     # Read with ORM
    user_query = session.query(User).filter(User.id == user.id)
    result = user_query.all()
    print('')
    print('Users (ORM)', result)
    print('')

    # Update
    user = result[0]
    user.name ='david'
    session.commit()  # Visible outside the

    # Delete
    session.delete(user)
    session.commit()

    # sleep(4)  Slow things down...

    # Clean-up thread session
    session.remove()


# Shotgun all queries (with thread protection for sessions!)
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as e:
    futures = {e.submit(run): i for i in range(JOBS)}

    for future in as_completed(futures):
        try:
            print(future.result())
        except Exception as e:
            print(u"\n\nError occured on number {}: {}\n\n".format(futures[future], e))

