# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from helpers import session_context, MAIN_URI
from ticketmodels import Base, create_data

engine = create_engine(MAIN_URI, echo=True)
Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

# Build some demo data
with session_context(sessionmaker(bind=engine)) as session:
    create_data(session)