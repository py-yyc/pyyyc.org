# -*- coding: utf-8 -*-
#
from __future__ import absolute_import

from contextlib import contextmanager

# Connection constants
POSTGRESQL_URI = 'postgresql://pyyyc:pyyyc@127.0.0.1:5432/pyyyc'
SQLITE_URI = 'sqlite:///:memory:'
MAIN_URI = POSTGRESQL_URI


@contextmanager
def session_context(SessionMaker):
    """
    Provide a transactional scope around a series of operations.
    """
    session = SessionMaker()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()