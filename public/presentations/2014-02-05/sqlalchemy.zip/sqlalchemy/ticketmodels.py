# -*- coding: utf-8 -*-
#
from __future__ import absolute_import
from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship


# Setup base class
Base = declarative_base()


class Patron(Base):
    """
    A single theatre patron (person)
    """
    __tablename__ = 'patron'

    id = Column(Integer, primary_key=True)
    first = Column(String)
    last = Column(String)

    def __repr__(self):
        return '<Patron #{id} \"{first} {last}\">'.format(id=self.id, first=self.first, last=self.last)

    def buy_ticket(self, ticket):
        """
        Purchase a ticket with this patron
        """
        if ticket.patron and ticket.patron != self:
            raise ValueError(u"Ticket already purchased!")
        elif ticket.patron:
            return True

        ticket.patron = self
        return True


class Venue(Base):
    """
    A venue where a play would take place
    """
    __tablename__ = 'venue'

    id = Column(Integer, primary_key=True)
    name = Column(String)

    def __repr__(self):
        return '<Venue #{id} \"{name}\">'.format(id=self.id, name=self.name)


class Seat(Base):
    """
    A seat within a given venue
    """
    __tablename__ = 'seat'

    id = Column(Integer, primary_key=True)
    section = Column(String)
    row = Column(String)
    seat = Column(Integer)

    # Venue this seat is in
    venue_id = Column(Integer, ForeignKey('venue.id'))
    venue = relationship("Venue", backref="seats")

    def __repr__(self):
        return '<Seat #{id} {section}-{row}-{seat}>'.format(id=self.id, section=self.section, row=self.row,
                                                            seat=self.seat)

class Play(Base):
    """
    A play run.  Contains a series of performances.
    """
    __tablename__ = 'play'

    id = Column(Integer, primary_key=True)
    name = Column(String)

    venue_id = Column(Integer, ForeignKey('venue.id'))
    venue = relationship('Venue', backref="plays")

    def __repr__(self):
        return '<Play #{id} \"{name}\">'.format(id=self.id, name=self.name)


class Performance(Base):
    """
    A performance within a play run
    """
    __tablename__ = 'performance'

    id = Column(Integer, primary_key=True)
    code = Column(String)
    date = Column(DateTime)

    # Play this performance belongs to
    play_id = Column(Integer, ForeignKey('play.id'))
    play = relationship("Play", backref="performances")

    def __repr__(self):
        return '<Performance #{id} \"{code}\" @ {date}>'.format(id=self.id, code=self.code, date=self.date)


class Ticket(Base):
    """
    An individual ticket for a single performance in a single seat
    """
    __tablename__ = 'ticket'

    id = Column(Integer, primary_key=True)

    # Performance this ticket is for
    performance_id = Column(Integer, ForeignKey('performance.id'))
    performance = relationship("Performance", backref="tickets")

    # Seat within Venue
    seat_id = Column(Integer, ForeignKey('seat.id'))
    seat = relationship("Seat", backref="tickets")

    # Ticket Owner (Purchaser)
    patron_id = Column(Integer, ForeignKey('patron.id'))
    patron = relationship("Patron", backref="tickets")

    def __repr__(self):
        return '<Ticket #{id}>'.format(id=self.id)


def create_data(session):
    """
    Create some demo data
    """
    # -------------------------------------------------------------------------
    # PATRONS
    # -------------------------------------------------------------------------
    patrons = [
        Patron(first="David", last="McKeone"),
        Patron(first="Guido", last="VanRossum"),
        Patron(first="Raymond", last="Hettinger"),
        Patron(first="Mike", last="Bayer"),
        Patron(first="Tim", last="Peters"),
        Patron(first="Armin", last="Ronacher"),
        Patron(first="Kenneth", last="Reitz"),
        Patron(first="Bob", last="Martin"),
        Patron(first="Alex", last="Martelli")
    ]

    for patron in patrons:
        session.add(patron)

    # -------------------------------------------------------------------------
    # VENUES, SEATS
    # -------------------------------------------------------------------------
    big_venue = Venue(name="Big Amphitheatre")
    for section in 'ABCD':
        for row in [str(i) for i in range(20)]:
            for seat in range(5):
                Seat(venue=big_venue, section=section, row=row, seat=seat)

    small_venue = Venue(name="Black box")
    for section in 'AD':
        for row in [str(i) for i in range(10)]:
            for seat in range(5):
                Seat(venue=small_venue, section=section, row=row, seat=seat)

    session.add(big_venue)
    session.add(small_venue)

    # -------------------------------------------------------------------------
    # PLAYS, PERFORMANCES, TICKETS
    # -------------------------------------------------------------------------
    theatre_sports = Play(venue=small_venue, name="Theatre Sports")
    Performance(play=theatre_sports, code="1-WED", date=datetime(2014, 5, 14, 18, 00))

    wine_tasting = Play(venue=small_venue, name="Wine Tasting")
    Performance(play=wine_tasting, code="1-WED", date=datetime(2014, 5, 21, 18, 00))

    phantom = Play(venue=big_venue, name="Phantom of the Opera")
    Performance(play=phantom, code="1-FRI", date=datetime(2014, 5, 23, 14, 00))
    Performance(play=phantom, code="1-SAT", date=datetime(2014, 5, 23, 19, 30))
    Performance(play=phantom, code="2-FRI", date=datetime(2014, 5, 24, 14, 00))
    Performance(play=phantom, code="2-SAT", date=datetime(2014, 5, 24, 19, 30))

    wicked = Play(venue=big_venue, name="Wicked")
    Performance(play=wicked, code="1-FRI", date=datetime(2014, 5, 30, 14, 00))
    Performance(play=wicked, code="1-SAT", date=datetime(2014, 5, 30, 19, 30))
    Performance(play=wicked, code="2-FRI", date=datetime(2014, 5, 31, 14, 00))
    Performance(play=wicked, code="2-SAT", date=datetime(2014, 5, 31, 19, 30))

    book_of_mormon = Play(venue=big_venue, name="Book of Mormon")
    Performance(play=book_of_mormon, code="1-FRI", date=datetime(2014, 6, 6, 14, 00))
    Performance(play=book_of_mormon, code="1-SAT", date=datetime(2014, 6, 6, 19, 30))
    Performance(play=book_of_mormon, code="2-FRI", date=datetime(2014, 6, 7, 14, 00))
    Performance(play=book_of_mormon, code="2-SAT", date=datetime(2014, 6, 7, 19, 30))

    # Create all tickets.  One per seat in venue.
    for play in (theatre_sports, wine_tasting, phantom, wicked, book_of_mormon):
        for performance in play.performances:
            for seat in play.venue.seats:
                Ticket(performance=performance, seat=seat)




